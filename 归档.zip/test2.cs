using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int[] arrayA = { 4, 2, 8, 3, 6, 1, 7 };
        Solution(arrayA);
    }

    static void Solution(int[] arrayA)
    {
        List<int> result = new List<int>();
        for (int i = 0; i < arrayA.Length; i++)
        {
            int layer = FindMaxNumber(result, arrayA[i]);
            result.Add(layer);
        }
        Console.WriteLine(string.Join(", ", result));
    }

    static int FindMaxNumber(List<int> arraryB, int ele)
    {
        if (arraryB.Contains(ele))
        {
            return FindMaxNumber(arraryB, ele - 1);
        }
        else
        {
            return ele;
        }
    }
}
