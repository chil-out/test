using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        string letters = "YourInputString"; // Replace with your input string
        int result = Solution(letters);
        Console.WriteLine(result);
    }

    static int Solution(string letters)
    {
        Dictionary<int, (int? firstUpperIndex, int? lastLowerIndex)> resultMap = new Dictionary<int, (int? firstUpperIndex, int? lastLowerIndex)>();

        char[] chars = letters.ToCharArray();

        for (int i = 0; i < chars.Length; i++)
        {
            char currentChar = chars[i];
            int charCode = (int)currentChar;

            if (charCode >= 65 && charCode <= 90)
            {
                int lowerCaseCode = charCode + 32;
                if (resultMap.TryGetValue(lowerCaseCode, out var current))
                {
                    if (current.firstUpperIndex == null)
                    {
                        current.firstUpperIndex = i;
                    }
                }
                else
                {
                    resultMap[lowerCaseCode] = (firstUpperIndex: i, lastLowerIndex: null);
                }
            }
            else if (charCode >= 97 && charCode <= 122)
            {
                if (resultMap.TryGetValue(charCode, out var current))
                {
                    current.lastLowerIndex = i;
                }
                else
                {
                    resultMap[charCode] = (firstUpperIndex: null, lastLowerIndex: i);
                }
            }
        }

        int count = 0;

        foreach (var kvp in resultMap)
        {
            if (kvp.Value.lastLowerIndex != null && kvp.Value.firstUpperIndex != null)
            {
                if (kvp.Value.lastLowerIndex < kvp.Value.firstUpperIndex)
                {
                    count++;
                }
            }
        }

        return count;
    }
}
