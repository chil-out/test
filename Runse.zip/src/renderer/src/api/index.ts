import * as openaiReq from './openai'

export default openaiReq
