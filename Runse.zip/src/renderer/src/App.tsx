import {
  AllHTMLAttributes,
  createContext,
  Dispatch,
  MutableRefObject,
  SetStateAction,
  useRef,
  useState
} from 'react'
import OpenAIAPI from './api/openai/openaiAPI'
import MainButton from './components/MainButton'
import MainPanel from './components/MainPanel'

export interface AppContextI {
  appMode: AppMode
  setAppMode: Dispatch<SetStateAction<AppMode>>
  openAIAPIRef: MutableRefObject<OpenAIAPI>
  stream: boolean
  setStream: Dispatch<SetStateAction<boolean>>
}

// context
export const AppContext = createContext<AppContextI | null>(null)

export enum AppMode {
  suspension = 'AppMode/suspension',
  expand = 'AppMode/expand',
  bigger = 'AppMode/bigger'
}

interface AppProps extends AllHTMLAttributes<HTMLDivElement> {}

export default function App({ className }: AppProps): JSX.Element {
  // state
  const [appMode, setAppMode] = useState<AppMode>(AppMode.suspension)


  const [stream, setStream] = useState(true)

  // ref
  const openAIAPIRef = useRef(new OpenAIAPI())

  return (
    <AppContext.Provider
      value={{
        appMode,
        setAppMode,
        openAIAPIRef,
        stream,
        setStream
      }}
    >
      <div className="transition-all duration-300 ease-in-out">
        {appMode === AppMode.suspension ? <MainButton /> : <MainPanel />}
      </div>
    </AppContext.Provider>
  )
}
