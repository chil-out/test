// import ioHook from 'iohook'
import { throttle, debounce } from 'lodash'
import { uIOhook } from 'uiohook-napi'

export type MouseCallback = () => void

export class MouseDragHandler {
  // endPosition: Position

  clickCount = 0

  isMouseDragging = false

  _mouseUpUserCallback?: MouseCallback

  _mouseDownUserCallback?: MouseCallback

  constructor(mouseDownUserCallback?: MouseCallback, mouseUpUserCallback?: MouseCallback) {
    this._mouseUpUserCallback = mouseUpUserCallback
    this._mouseDownUserCallback = mouseDownUserCallback
  }

  listen: () => void = () => {
    console.log('Start Listen Mouse Event Now.')

    uIOhook.on('mousedown', this._mouseDownHandler)
    uIOhook.on('mouseup', () => {
      this.clickCount++

      debounce(this._mouseUpHandler, 300)()
    })

    uIOhook.start()

  }

  stop: () => void = () => {
    console.log('停止监听鼠标事件。')
    uIOhook.stop()
  }

  _mouseDragHandler: () => void = () => {
    this.isMouseDragging = true
  }

  _mouseDownHandler: () => void = () => {
    // this.isMouseDragging = false

    // console.log('down')

    if (this._mouseDownUserCallback) {
      this._mouseDownUserCallback()
    }
  }

  _mouseUpHandler: () => void = () => {

    if (this._mouseUpUserCallback) {
      if (this.clickCount >= 2) {
        console.log('double click')

        this._mouseUpUserCallback()
      } else if (this.isMouseDragging) {
        this._mouseUpUserCallback()
      }
    }
    this.clickCount = 0
    this.isMouseDragging = false
  }
}
