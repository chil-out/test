import { resolve } from 'path'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'
import react from '@vitejs/plugin-react'
import svgr from 'vite-plugin-svgr'

export default defineConfig({
  main: {
    plugins: [externalizeDepsPlugin({ exclude: ['clipboardy'] })]
  },
  preload: {
    plugins: [externalizeDepsPlugin()]
  },
  renderer: {
    server: {
      proxy: {
        '/api/openai': {
          target: '',
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api\/openai/, '')
        }
      }
    },
    resolve: {
      alias: [{ find: '@renderer', replacement: resolve('src/renderer/src') }]
    },
    plugins: [react(), svgr()]
  }
})
