import {
  app,
  shell,
  BrowserWindow,
  screen,
  ipcMain,
  Tray,
  Menu,
  clipboard,
  Notification
} from 'electron'
import process from 'process'
import path from 'path'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import copySelectedText from './copySelectedText'
import { MouseDragHandler } from './handler'

enum WindowMode {
  expand = 'WindowMode/expand',
  hover = 'WindowMode/hover',
  suspension = 'WindowMode/suspension',
  bigger = 'WindowMode/bigger'
}

let ifCopyWhenExpand = true

function createWindow(): BrowserWindow {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 31,
    height: 31,
    x: 1300,
    y: 700,
    type: 'toolbar',
    alwaysOnTop: true,
    show: false,
    movable: true,
    useContentSize: true,
    frame: false,
    resizable: false,
    focusable: false,
    transparent: true,
    autoHideMenuBar: true,
    icon: path.resolve(__dirname, '../../public/img/favicon.ico'),
    webPreferences: {
      nodeIntegration: true,
      preload: path.join(__dirname, '../preload/index.js')
    }
  })

  mainWindow.once('ready-to-show', () => {
    // for debugging
    // mainWindow.show()
    // mainWindow.webContents.openDevTools()
  })

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'))
  }

  return mainWindow
}

app.whenReady().then(() => {
  electronApp.setAppUserModelId('Runse')

  app.on('browser-window-created', (_, window) => {
    optimizer.watchWindowShortcuts(window)
  })

  if (process.platform === 'win32') {
    app.setAppUserModelId('Runse')
  }

  // window
  const mainWindow = createWindow()

  // tray
  const tray = new Tray(path.join(__dirname, '../../public/img/favicon.ico'))

  // var
  let windowMode: WindowMode = WindowMode.suspension
  let pin = false

  // contextmenu
  const contextMenu = Menu.buildFromTemplate([
    {
      label: '打开',
      click: (): void => {
        mainWindow.show()
        mainWindow.webContents.send('expand', false)
      }
    },
    {
      label: '最小化',
      click: (): void => {
        mainWindow.hide()
      }
    },
    {
      label: '退出',
      click: (): void => {
        app.quit()
      }
    }
  ])

  tray.setToolTip('Runse')

  tray.setContextMenu(contextMenu)

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })

  mainWindow.webContents.on('did-finish-load', () => {
    mainWindow.webContents.setZoomFactor(1.0)

    const handler = new MouseDragHandler(mouseDownUserCallback, mouseUpUserCallback)

    handler.listen()

  })

  const mouseUpUserCallback = async (): Promise<void> => {
    const cursor = screen.getCursorScreenPoint()

    const { x, y } = cursor

    if (isPositionOnWindow(x, y, mainWindow)) return

    console.log('mouseUp event: current winMode is',windowMode)
    // re-locate
    if (windowMode === WindowMode.suspension) {
      mainWindow.setPosition(x + 10, y + 10)

      mainWindow.show()
    }

    // sendCopiedText
    if (pin && ifCopyWhenExpand) {
      try {
        const text = await copySelectedText()

        mainWindow.webContents.send('sendCopiedText', text)
      } catch (err) {
        console.log(err)
      }
    }
  }

  const mouseDownUserCallback = (): void => {
    const cursor = screen.getCursorScreenPoint()

    const { x, y } = cursor

    console.log('mouseDown event: current winMode is',windowMode)
    if (isPositionOnWindow(x, y, mainWindow)) return

    if (windowMode === WindowMode.expand || windowMode === WindowMode.bigger) {
      if (pin) {
        return
      } else {
        mainWindow.hide()

        mainWindow.setFocusable(false)
        mainWindow.setResizable(false)
        mainWindow.setContentSize(31, 31)

        windowMode = WindowMode.suspension

        mainWindow.webContents.send('suspension')
      }
    } else {
      mainWindow.hide()
    }
  }

  ipcMain.handle('bigger', async (event) => {
    windowMode = WindowMode.bigger

    mainWindow.setFocusable(true)
    mainWindow.setResizable(true)

    const [width, height] = mainWindow.getContentSize()

    mainWindow.setContentSize(width, height + 400 > 820 ? 820 : height + 400)
  })

  ipcMain.handle('expand', async (event, fromSuspension: boolean) => {
    windowMode = WindowMode.expand

    mainWindow.setFocusable(true)
    mainWindow.setResizable(true)
    mainWindow.setContentSize(660, 420)
    mainWindow.setOpacity(1)
    mainWindow.setMinimumSize(400, 340)

    if (fromSuspension) {
      try {
        const text = await copySelectedText()
        mainWindow.webContents.send('sendCopiedText', text)
      } catch (err) {
        console.log(err)
      }
    } else {
      const [width] = mainWindow.getContentSize()

      mainWindow.setContentSize(width, 420)
    }
  })

  ipcMain.handle('suspension', (event) => {
    windowMode = WindowMode.suspension

    mainWindow.setMinimumSize(30, 30)
    mainWindow.setFocusable(false)
    mainWindow.setResizable(false)
    mainWindow.setOpacity(0.75)
    mainWindow.setContentSize(31, 31)
  })

  ipcMain.handle('openMenu', (event) => {
    console.log('openMenu')
  })

  ipcMain.handle('pin', (event, isPinVal) => {
    pin = isPinVal
  })

  ipcMain.handle('sendTranslateReq', (event) => {})

  ipcMain.handle('copy', (event, text) => {
    clipboard.writeText(text)
  })


  ipcMain.handle('openBrowser', async (event, url) => {
    shell.openExternal(url)
  })

  ipcMain.handle('setIfCopyWhenExpand', async (event, val: boolean) => {
    console.log('setIfCopyWhenExpand', val)
    ifCopyWhenExpand = val
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

function isPositionOnWindow(x: number, y: number, window: BrowserWindow): boolean {
  const [width, height] = window.getSize()

  const [winX, winY] = window.getPosition()

  if (x <= winX + width && x >= winX && y <= winY + height && y >= winY) {
    return true
  } else {
    return false
  }
}
