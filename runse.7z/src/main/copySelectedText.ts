import { clipboard } from 'electron'

import { uIOhook, UiohookKeyboardEvent } from 'uiohook-napi'

uIOhook.start()

/**
 * 剪贴板监听事件
 */
uIOhook.on('keydown', (e: UiohookKeyboardEvent) => {
  const status = e.ctrlKey
  if (status && e.keycode === 46) {
    setTimeout(() => {
      let text = clipboard.readText().replace('\r', '').replace('\n', '').trim()

      console.log(text)
      clipboard.writeText(text)
    }, 300)
  }
})

// TODO 鼠标未移动不进行复制。
const copySelectedText = async (): Promise<string> => {
  // const now = Date.now()

  // const buffer = clipboard.readText()

  return new Promise((resolve, reject) => {
    // console.log('missing robot js')
    // robot.keyToggle('control', 'down')

    // robot.keyTap('c')

    // robot.keyToggle('control', 'up')

    setTimeout(() => {
      // const text = clipboard.readText().replace('\r', '').replace('\n', '').trim()

      let text  = clipboard.readText()

      resolve(text)
    }, 50)
  })
}

export default copySelectedText
